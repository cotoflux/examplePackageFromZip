<?php

if(!function_exists('print_rand')){
    function print_rand(){
        echo rand();
    }
}