<?php

require("helper.php");

echo "This is the random number". PHP_EOL;
print_rand();